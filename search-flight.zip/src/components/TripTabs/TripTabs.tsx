import React from 'react';

const TripTabs = () => {

    return (
        <ul className="lfh-tabs">
            <li className='active'>One way</li>
        </ul>
    )
}
export default TripTabs;